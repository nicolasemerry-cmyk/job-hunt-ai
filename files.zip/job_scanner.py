#!/usr/bin/env python3
"""
Job Scanner — Nicolas Merry
Scans creative job boards for relevant video/film production roles.
Run with: python job_scanner.py
Results saved to: job_report_YYYY-MM-DD.html
"""

import requests
from bs4 import BeautifulSoup
import json
import os
import re
from datetime import datetime
from urllib.parse import urljoin
import time

# ─── CONFIGURATION ───────────────────────────────────────────────────────────

KEYWORDS_TITLE = [
    "video editor", "video producer", "videographer", "content producer",
    "video producer and editor", "film editor", "post-production",
    "post production", "motion graphics", "editor", "producer",
    "content creator", "digital content", "social media video",
    "music video", "filmmaker", "film maker", "colour grading",
    "color grading", "camera operator"
]

KEYWORDS_SKILLS = [
    "premiere pro", "davinci resolve", "after effects", "multicam",
    "sony", "mirrorless", "live streaming", "youtube", "final cut"
]

EXCLUDE_TERMS = [
    "casting", "audition", "actor", "actress", "model", "voiceover",
    "voice over", "theatre", "theater", "dancer", "musician",
    "accountant", "finance", "developer", "software engineer",
    "data analyst", "solicitor", "legal"
]

# Headers to avoid bot blocks
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-GB,en;q=0.9",
}

STATE_FILE = "last_seen.json"

# ─── SITES CONFIG ─────────────────────────────────────────────────────────────

SITES = [
    {
        "name": "Creative Lives in Progress",
        "url": "https://creativelivesinprogress.com/opportunities",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/opportunities/",
    },
    {
        "name": "UAL Creative Opportunities",
        "url": "https://creativeopportunities.arts.ac.uk/vacancies/",
        "job_selector": "a.vacancy-title, h2 a, h3 a, .job-title a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/vacancies/",
    },
    {
        "name": "If You Could Jobs",
        "url": "https://www.ifyoucouldjobs.com/jobs",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/jobs/",
    },
    {
        "name": "Run The Check",
        "url": "https://www.runthecheck.com/",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": None,
    },
    {
        "name": "Workculture",
        "url": "https://workculture.uk/jobs/",
        "job_selector": "h2 a, h3 a, .job-title a, article a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/jobs/",
    },
    {
        "name": "Doors Open",
        "url": "https://www.doorsopen.co/jobs",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/jobs/",
    },
    {
        "name": "Create Jobs Community",
        "url": "https://community.createjobslondon.org/opportunities",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": None,
    },
    {
        "name": "Creative Access (Junior, London)",
        "url": "http://opportunities.creativeaccess.org.uk/jobs/junior?geo_location=London%2C+UK&lon=-0.1275862&lat=51.5072178&radius=80&locationType=locality&location=London&country=United+Kingdom&administrative_area_level_1=England&field_job_experience=1410",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/jobs/",
    },
    {
        "name": "Major Players",
        "url": "https://www.majorplayers.co/en/jobs",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/jobs/",
    },
    {
        "name": "Tomorrow Worldwide",
        "url": "https://tomorrow-worldwide.com/job-listings/",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": None,
    },
    {
        "name": "Mandy (Crew Jobs UK)",
        "url": "https://www.mandy.com/uk/jobs/crew/",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/job/",
    },
    {
        "name": "ProductionBase",
        "url": "https://www.productionbase.co.uk/film-tv-jobs",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/job",
    },
    {
        "name": "The Talent Manager",
        "url": "https://www.thetalentmanager.com/jobs",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/job",
    },
    {
        "name": "ScreenSkills",
        "url": "https://www.screenskills.com/jobs/",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": "/jobs/",
    },
    {
        "name": "Burberry Careers",
        "url": "https://burberrycareers.com/go/Search-and-Apply/",
        "job_selector": "a",
        "title_attr": "text",
        "link_attr": "href",
        "link_filter": None,
    },
]

# ─── HELPERS ──────────────────────────────────────────────────────────────────

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {}

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

def is_relevant(title):
    title_lower = title.lower().strip()
    if len(title_lower) < 5:
        return False
    for ex in EXCLUDE_TERMS:
        if ex in title_lower:
            return False
    for kw in KEYWORDS_TITLE:
        if kw in title_lower:
            return True
    return False

def fetch_jobs(site):
    """Fetch job listings from a site and return list of (title, url) tuples."""
    results = []
    try:
        resp = requests.get(site["url"], headers=HEADERS, timeout=15)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "lxml")

        seen_titles = set()
        links = soup.select(site["job_selector"])

        for tag in links:
            title = tag.get_text(separator=" ", strip=True)
            href = tag.get("href", "")

            if not title or not href:
                continue

            # Filter by link pattern if specified
            if site["link_filter"] and site["link_filter"] not in href:
                continue

            # Make absolute URL
            if href.startswith("http"):
                full_url = href
            else:
                full_url = urljoin(site["url"], href)

            # Deduplicate
            if title in seen_titles:
                continue
            seen_titles.add(title)

            if is_relevant(title):
                results.append({"title": title, "url": full_url})

    except Exception as e:
        results.append({"title": f"⚠️ Error fetching site: {e}", "url": site["url"], "error": True})

    return results

# ─── HTML REPORT ──────────────────────────────────────────────────────────────

def generate_report(all_results, new_counts, date_str):
    total_new = sum(new_counts.values())
    total_found = sum(len(v["jobs"]) for v in all_results.values())

    site_rows = ""
    for site_name, data in all_results.items():
        jobs = data["jobs"]
        new = new_counts.get(site_name, 0)
        status = f'<span class="badge new">{new} new</span>' if new else '<span class="badge seen">no new</span>'
        error = any(j.get("error") for j in jobs)

        if error:
            status = '<span class="badge error">error</span>'

        job_items = ""
        for j in jobs:
            is_new = j.get("is_new", False)
            new_tag = ' <span class="new-tag">NEW</span>' if is_new else ""
            if j.get("error"):
                job_items += f'<li class="error-item">⚠️ {j["title"]}</li>'
            else:
                job_items += f'<li{"class=\"new-item\"" if is_new else ""}><a href="{j["url"]}" target="_blank">{j["title"]}</a>{new_tag}</li>'

        if not jobs:
            job_items = "<li class='none'>No matching jobs found</li>"

        site_rows += f"""
        <div class="site-block{'  error-block' if error else ''}">
            <div class="site-header">
                <h2>{site_name}</h2>
                <div class="site-meta">{status} &nbsp;·&nbsp; <a href="{data['url']}" target="_blank">open site ↗</a></div>
            </div>
            <ul>{job_items}</ul>
        </div>
        """

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Job Scan — {date_str}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #0f0f0f; color: #e0e0e0; padding: 32px 24px; }}
  .header {{ max-width: 860px; margin: 0 auto 36px; border-bottom: 1px solid #2a2a2a; padding-bottom: 20px; }}
  .header h1 {{ font-size: 22px; font-weight: 600; color: #86E0A8; letter-spacing: -0.3px; }}
  .header p {{ font-size: 13px; color: #777; margin-top: 6px; }}
  .summary {{ display: flex; gap: 20px; margin-top: 14px; }}
  .stat {{ background: #1a1a1a; border: 1px solid #2a2a2a; border-radius: 8px; padding: 12px 18px; }}
  .stat .num {{ font-size: 26px; font-weight: 700; color: #86E0A8; }}
  .stat .label {{ font-size: 11px; color: #666; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 2px; }}
  .sites {{ max-width: 860px; margin: 0 auto; display: grid; gap: 16px; }}
  .site-block {{ background: #1a1a1a; border: 1px solid #2a2a2a; border-radius: 10px; padding: 20px 24px; }}
  .site-block.error-block {{ border-color: #3a2020; }}
  .site-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }}
  .site-header h2 {{ font-size: 15px; font-weight: 600; color: #ccc; }}
  .site-meta {{ font-size: 12px; color: #555; }}
  .site-meta a {{ color: #555; text-decoration: none; }}
  .site-meta a:hover {{ color: #86E0A8; }}
  .badge {{ font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 4px; }}
  .badge.new {{ background: #1a3a26; color: #86E0A8; }}
  .badge.seen {{ background: #1e1e1e; color: #444; }}
  .badge.error {{ background: #3a1a1a; color: #e08686; }}
  ul {{ list-style: none; display: flex; flex-direction: column; gap: 8px; }}
  li a {{ font-size: 14px; color: #aaa; text-decoration: none; line-height: 1.4; }}
  li a:hover {{ color: #86E0A8; }}
  li.new-item a {{ color: #e0e0e0; font-weight: 500; }}
  .new-tag {{ font-size: 10px; font-weight: 700; background: #1a3a26; color: #86E0A8; padding: 2px 6px; border-radius: 3px; margin-left: 6px; vertical-align: middle; }}
  li.none {{ font-size: 13px; color: #444; font-style: italic; }}
  li.error-item {{ font-size: 13px; color: #e08686; }}
  .footer {{ max-width: 860px; margin: 32px auto 0; font-size: 12px; color: #444; text-align: center; }}
</style>
</head>
<body>
<div class="header">
  <h1>Job Scan Report</h1>
  <p>Run on {date_str}</p>
  <div class="summary">
    <div class="stat"><div class="num">{total_new}</div><div class="label">New since last run</div></div>
    <div class="stat"><div class="num">{total_found}</div><div class="label">Total matching jobs</div></div>
    <div class="stat"><div class="num">{len(all_results)}</div><div class="label">Sites scanned</div></div>
  </div>
</div>
<div class="sites">
{site_rows}
</div>
<div class="footer">Generated by job_scanner.py · Keywords: video editor, video producer, videographer, content producer, filmmaker, motion graphics, post-production</div>
</body>
</html>"""
    return html

# ─── MAIN ─────────────────────────────────────────────────────────────────────

def main():
    date_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    file_date = datetime.now().strftime("%Y-%m-%d")

    print(f"\n🎬  Job Scanner — {date_str}")
    print("─" * 50)

    state = load_state()
    all_results = {}
    new_counts = {}

    for site in SITES:
        print(f"  Scanning: {site['name']}...", end=" ", flush=True)
        time.sleep(1)  # polite delay between requests

        jobs = fetch_jobs(site)
        site_key = site["name"]
        prev_urls = set(state.get(site_key, []))
        new_count = 0

        for job in jobs:
            if not job.get("error"):
                job["is_new"] = job["url"] not in prev_urls
                if job["is_new"]:
                    new_count += 1

        new_counts[site_key] = new_count
        all_results[site_key] = {"jobs": jobs, "url": site["url"]}

        # Update state with current URLs
        state[site_key] = [j["url"] for j in jobs if not j.get("error")]

        status = f"✅  {len(jobs)} found ({new_count} new)" if jobs and not any(j.get("error") for j in jobs) else "⚠️  error or no results"
        print(status)

    save_state(state)

    # Generate report
    report_html = generate_report(all_results, new_counts, date_str)
    report_file = f"job_report_{file_date}.html"

    with open(report_file, "w", encoding="utf-8") as f:
        f.write(report_html)

    total_new = sum(new_counts.values())
    total_found = sum(len(v["jobs"]) for v in all_results.values())

    print("─" * 50)
    print(f"  ✨  Done. {total_found} matching jobs found, {total_new} new since last run.")
    print(f"  📄  Report saved: {report_file}\n")

if __name__ == "__main__":
    main()
